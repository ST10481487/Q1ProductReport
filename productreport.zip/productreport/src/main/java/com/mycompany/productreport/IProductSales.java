/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.productreport;

/**
 *
 * @author Student
 */

public interface IProductSales {
    int TotalSales(int[][] productSales);

    double AverageSales(int[][] productSales);

    int MostSale(int[][] productSales);

}
