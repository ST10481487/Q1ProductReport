/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.productreport;

/**
 *
 * @author Student
 */

public class Main {

    public static void main(String[] args) {
        int[][] productSales = {
            {25, 15, 18}, // Month 1
            {18, 10, 15}, // Month 2
            {20, 12, 20}  // Month 3
        };

        PrintProduct printer = new PrintProduct();
        printer.printReport(productSales);
    }
}

