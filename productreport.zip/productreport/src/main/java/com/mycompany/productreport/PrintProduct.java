/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productreport;

/**
 *
 * @author Student
 */
public class PrintProduct {

    private final ProductSales sales;

    public PrintProduct() {
        this.sales = new ProductSales() {};
    }

    public void printTotalSales(int[][] productSales) {
        System.out.println("Total Sales:   " + sales.TotalSales(productSales));
    }

    public void printAverageSales(int[][] productSales) {
        System.out.println("Average sales: " + Math.round(sales.AverageSales(productSales)));
    }

    public void printMostPopularSale(int[][] productSales) {
        System.out.println("Most popular product: " + sales.MostSale(productSales));
    }

    public void printReport(int[][] productSales) {
        System.out.println("Product sales Report - 2026");
        System.out.println("---------------------------");
        printTotalSales(productSales);
        printAverageSales(productSales);
        printMostPopularSale(productSales);
    }
}
