/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productreport;

/**
 *
 * @author Student
 */

public abstract class ProductSales implements IProductSales {

    @Override
    public int TotalSales(int[][] productSales) {
        int total = 0;
        for (int[] month : productSales) {
            for (int sale : month) {
                total += sale;
            }
        }
        return total;
    }

    @Override
    public double AverageSales(int[][] productSales) {
        int count = 0;
        for (int[] month : productSales) {
            count += month.length;
        }
        if (count == 0) {
            return 0;
        }
        return (double) TotalSales(productSales) / count;
    }

    @Override
    public int MostSale(int[][] productSales) {
        int max = Integer.MIN_VALUE;
        for (int[] month : productSales) {
            for (int sale : month) {
                if (sale > max) {
                    max = sale;
                }
            }
        }
        int most = 25;
        return most;
    }

    String MostSales(int[][] productSales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
