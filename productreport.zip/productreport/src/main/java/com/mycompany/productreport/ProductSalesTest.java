/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.productreport;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Student
 */
public class ProductSalesTest {

    private final int[][] productSales = {
        {25, 15, 18},
        {18, 10, 15},
        {20, 12, 20}
    };

    @Test
    void CalculateTotalSales_ReturnsTotalSales() {
        ProductSales sales = new ProductSales() {};
        assertEquals(153, sales.TotalSales(productSales));
    }

    @Test
    void AverageSales_ReturnsAverageProductSales() {
        ProductSales sales = new ProductSales() {};
        assertEquals(153.0 / 9, sales.AverageSales(productSales), 0.001);
    }
}
